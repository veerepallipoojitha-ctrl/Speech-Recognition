// ==========================================
// SPEECH RECOGNITION PROJECT
// ==========================================


// Check browser support

const SpeechRecognition =
    window.SpeechRecognition ||
    window.webkitSpeechRecognition;


let recognition;


// ==========================================
// CREATE SPEECH RECOGNITION
// ==========================================

if (SpeechRecognition) {

    recognition = new SpeechRecognition();

    // Stop after the user finishes speaking

    recognition.continuous = false;

    // Do not show partial results

    recognition.interimResults = false;

    // Language

    recognition.lang = "en-US";


    // ======================================
    // WHEN RECOGNITION STARTS
    // ======================================

    recognition.onstart = function() {

        document.getElementById("status").innerText =
            "🎤 Listening... Please speak now.";

        document.getElementById("startButton").innerText =
            "🎤 Listening...";

    };


    // ======================================
    // WHEN SPEECH IS RECOGNIZED
    // ======================================

    recognition.onresult = function(event) {

        const transcript =
            event.results[0][0].transcript;


        document.getElementById("speechText").value =
            transcript;


        document.getElementById("status").innerText =
            "✅ Speech recognized successfully.";


        document.getElementById("startButton").innerText =
            "🎤 Start Speaking";


        // Automatically analyze

        analyzeSpeech();

    };


    // ======================================
    // ERROR HANDLING
    // ======================================

    recognition.onerror = function(event) {

        document.getElementById("status").innerText =
            "❌ Error: " + event.error;


        document.getElementById("startButton").innerText =
            "🎤 Start Speaking";

    };


    // ======================================
    // WHEN RECOGNITION STOPS
    // ======================================

    recognition.onend = function() {

        document.getElementById("startButton").innerText =
            "🎤 Start Speaking";

    };

}


// ==========================================
// START SPEECH RECOGNITION
// ==========================================

function startRecognition() {

    if (!recognition) {

        alert(
            "Speech recognition is not supported in this browser. Please use Google Chrome."
        );

        return;

    }


    try {

        recognition.start();

    } catch (error) {

        console.log(error);

    }

}


// ==========================================
// ANALYZE SPEECH
// ==========================================

function analyzeSpeech() {

    const text =
        document.getElementById("speechText").value.trim();


    if (text === "") {

        document.getElementById("analysisResult").innerHTML =
            "Please speak something first.";

        return;

    }


    // ======================================
    // WORD COUNT
    // ======================================

    const words =
        text
            .split(/\s+/)
            .filter(word => word.length > 0);


    const wordCount =
        words.length;


    // ======================================
    // CHARACTER COUNT
    // ======================================

    const characterCount =
        text.length;


    // ======================================
    // SENTENCE COUNT
    // ======================================

    const sentences =
        text
            .split(/[.!?]+/)
            .filter(sentence => sentence.trim().length > 0);


    const sentenceCount =
        sentences.length;


    // ======================================
    // AVERAGE WORD LENGTH
    // ======================================

    let totalWordCharacters = 0;


    words.forEach(function(word) {

        totalWordCharacters += word.length;

    });


    let averageWordLength = 0;


    if (wordCount > 0) {

        averageWordLength =
            (
                totalWordCharacters /
                wordCount
            ).toFixed(2);

    }


    // ======================================
    // DISPLAY STATISTICS
    // ======================================

    document.getElementById("wordCount").innerText =
        wordCount;


    document.getElementById("characterCount").innerText =
        characterCount;


    document.getElementById("sentenceCount").innerText =
        sentenceCount;


    // ======================================
    // DISPLAY ANALYSIS
    // ======================================

    document.getElementById("analysisResult").innerHTML =

        "<strong>Speech Analysis Result</strong><br><br>" +

        "Total Words: " +
        wordCount +
        "<br>" +

        "Total Characters: " +
        characterCount +
        "<br>" +

        "Total Sentences: " +
        sentenceCount +
        "<br>" +

        "Average Word Length: " +
        averageWordLength +
        " characters";

}


// ==========================================
// CLEAR TEXT
// ==========================================

function clearText() {

    document.getElementById("speechText").value = "";

    document.getElementById("wordCount").innerText = "0";

    document.getElementById("characterCount").innerText = "0";

    document.getElementById("sentenceCount").innerText = "0";

    document.getElementById("analysisResult").innerHTML = "";

    document.getElementById("status").innerText =
        "Click the button and start speaking.";

}